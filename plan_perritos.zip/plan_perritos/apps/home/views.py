from django.shortcuts import render
from django.http import HttpResponse
from apps.campana.models import Campana
from apps.evento.models import Evento
from apps.noticia.models import Noticia

# Create your views here.
def homepage(request):
    #campana = models.Campana.objects.order_by('fecha_fin').first()
    campana = list(filter(Campana.is_active, Campana.objects.order_by('fecha_fin')))
    evento = list(filter(Evento.is_active, Evento.objects.order_by('fecha_exec')))
    noticia1 = Noticia.objects.order_by('fecha_creacion')[0]
    noticia2 = Noticia.objects.order_by('fecha_creacion')[1]
    return render(request, 'inicio.html', {
        'campana': campana[0],
        'evento': evento[0],
        'noticia1': noticia1,
        'noticia2': noticia2,
    })