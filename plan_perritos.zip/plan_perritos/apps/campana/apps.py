from django.apps import AppConfig


class CampanaConfig(AppConfig):
    name = 'campana'
