from django.urls import re_path, path
from .views import campana_list, AsistenciaCampanaCreate, campana_csv
from django.contrib.auth.decorators import login_required

urlpatterns = [
    re_path(r'^lista$', campana_list, name='campana_listar'),
    re_path(r'^asistir$', AsistenciaCampanaCreate.as_view(),  name='campana_asistir'),
    re_path(r'^csv/(?P<id>\d+)$', login_required(campana_csv))
]
