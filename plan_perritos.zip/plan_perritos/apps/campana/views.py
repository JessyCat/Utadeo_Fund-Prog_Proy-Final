from django.shortcuts import render, redirect, get_object_or_404
from .models import Campana, AsistenciaCampana
from django.http import HttpResponseRedirect, HttpResponse
from django.views.generic import CreateView
from .forms import AsistenciaForm
from django.urls import reverse_lazy
# Create your views here.


def campana_list(request):
    campana = list(filter(Campana.is_active, Campana.objects.order_by('fecha_fin')))
    contexto = {'campana': campana}
    return render(request, 'campana/campana_list.html', contexto)

class AsistenciaCampanaCreate(CreateView):
    model = AsistenciaCampana
    template_name = 'campana/asistencia.html'
    form_class = AsistenciaForm
    success_url = reverse_lazy('campanas:campana_listar')
    #form_class.fields["campana"].queryset = Campana.objects.are_active()


    def get_context_data(self, **kwargs):
        context = super(AsistenciaCampanaCreate, self).get_context_data(**kwargs)
        if 'asistencia' not in context:
            context['asistencia'] = self.form_class(self.request.GET)
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(self.get_success_url())
        else:
            return self.render_to_response(self.get_context_data(form=form))


def campana_csv(request, id):
    from django.db import connection
    import csv

    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM campana_asistenciacampana WHERE campana_id = " + str(id))
        result_csv = cursor.fetchall()

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="asistencia a campana con id '+ str(id) + '.csv"'

    writer = csv.writer(response)

    for i in result_csv:
        writer.writerow(i)

    return response





