import datetime
from django.db import models

# Create your models here.

# class CampanaManager(models.Manager):
#     def get_queryset(self):
#         from django.db import connection
#         with connection.cursor() as cursor:
#             cursor.execute("""
#             SELECT *
#             FROM campana_campana
#             WHERE fecha_fin > now()
#             ORDER BY fecha_fin ASC;
#             """)
#             result_list = []
#             for row in cursor.fetchall():
#                 campaign = self.model(id=row[0],
#                                       titulo=row[1],
#                                       fecha_creacion=row[2],
#                                       fecha_inicio=row[3],
#                                       fecha_fin=row[4],
#                                       desc=row[5],
#                                       imagen1=row[6],
#                                       imagen2=row[7],)
#                 result_list.append(campaign)
#
#         return result_list


class Campana(models.Model):
    titulo = models.CharField(max_length=50, blank=False, unique=True)
    fecha_creacion = models.DateField(auto_now_add=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    desc = models.TextField()
    imagen1 = models.ImageField(upload_to='campana/%Y/%m/%d')
    imagen2 = models.ImageField(upload_to='campana/%Y/%m/%d')

    #campanas_activas = CampanaManager()

    def __str__(self):
        return self.titulo

    def is_active(self):
        now = datetime.date.today()
        return self.fecha_fin >= now


class AsistenciaCampana(models.Model):
    nombres = models.CharField(max_length=50, blank=False)
    apellidos = models.CharField(max_length=50, blank=False)
    cedula = models.IntegerField(unique=True)
    email = models.EmailField(blank=False)
    campana = models.ForeignKey(Campana, null=True, blank=True, on_delete=models.CASCADE)
