import datetime
from django import forms
from .models import AsistenciaCampana, Campana

class AsistenciaForm(forms.ModelForm):
    campana = forms.ModelChoiceField(
        queryset=Campana.objects.filter(fecha_fin__gte=datetime.date.today()),
        widget=forms.Select(attrs={'class':'form-control'}),
        label='Campañas Disponibles',
        empty_label = '--- ¿A que campaña deseas asistir? ---',
    )
    class Meta:
        model = AsistenciaCampana
        fields = '__all__'
        labels = {
            'nombres': 'Nombres',
            'apellidos': 'Apellidos',
            'cedula': 'Numero de identificación',
            'email': 'Correo Electrónico',
        }
        widgets = {
            'nombres': forms.TextInput(attrs={'class':'form-control'},),
            'apellidos': forms.TextInput(attrs={'class':'form-control'}),
            'cedula': forms.NumberInput(attrs={'class':'form-control'}),
            'email': forms.EmailInput(attrs={'class':'form-control'}),
        }
