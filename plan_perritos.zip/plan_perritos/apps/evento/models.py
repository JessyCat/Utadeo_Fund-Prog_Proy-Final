import datetime
from django.db import models
# Create your models here.

class Evento(models.Model):
    titulo = models.CharField(max_length=50, blank=False, unique=True)
    fecha_creacion = models.DateField(auto_now_add=True)
    fecha_exec = models.DateField()
    hora_inicio = models.TimeField(blank=False)
    hora_fin = models.TimeField(blank=True)
    precio = models.CharField(max_length=7, blank=True)
    desc = models.TextField()
    ubicacion = models.CharField(max_length=50, blank=False)
    imagen1 = models.ImageField(upload_to='campana/%Y/%m/%d', blank=False)
    imagen2 = models.ImageField(upload_to='campana/%Y/%m/%d', blank=True)

    def __str__(self):
        return self.titulo

    def is_active(self):
        now = datetime.date.today()
        return self.fecha_exec > now

class AsistenciaEvento(models.Model):
    nombres = models.CharField(max_length=50, blank=False)
    apellidos = models.CharField(max_length=50, blank=False)
    cedula = models.IntegerField(unique=True)
    email = models.EmailField(blank=False)
    evento = models.ForeignKey(Evento, null=True, blank=True, on_delete=models.CASCADE)
