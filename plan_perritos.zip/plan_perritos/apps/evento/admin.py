from django.contrib import admin
from .models import Evento
# Register your models here.
admin.site.register(Evento)