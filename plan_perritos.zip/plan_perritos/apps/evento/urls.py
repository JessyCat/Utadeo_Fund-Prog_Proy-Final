from django.urls import re_path
from .views import evento_list, AsistenciaEventoCreate

urlpatterns = [
    re_path(r'^lista', evento_list, name='evento_listar'),
    re_path(r'^asistir$', AsistenciaEventoCreate.as_view(),  name='evento_asistir'),
]
