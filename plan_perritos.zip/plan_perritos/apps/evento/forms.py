import datetime
from django import forms
from .models import AsistenciaEvento, Evento


class AsistenciaForm(forms.ModelForm):
    evento = forms.ModelChoiceField(
        queryset=Evento.objects.filter(fecha_exec__gte=datetime.date.today()),
        widget=forms.Select(attrs={'class':'form-control'}),
        label='Eventos Disponibles',
        empty_label = '--- ¿A que evento deseas asistir? ---'
    )
    class Meta:
        model = AsistenciaEvento
        fields = '__all__'
        labels = {
            'nombres': 'Nombres',
            'apellidos': 'Apellidos',
            'cedula': 'Numero de identificación',
            'email': 'Correo Electrónico',
        }
        widgets = {
            'nombres': forms.TextInput(attrs={'class':'form-control'},),
            'apellidos': forms.TextInput(attrs={'class':'form-control'}),
            'cedula': forms.NumberInput(attrs={'class':'form-control'}),
            'email': forms.EmailInput(attrs={'class':'form-control'}),
        }
