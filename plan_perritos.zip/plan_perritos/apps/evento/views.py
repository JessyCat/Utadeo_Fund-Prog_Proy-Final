from django.shortcuts import render
from .models import Evento, AsistenciaEvento
from .forms import AsistenciaForm
from django.views.generic import CreateView
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect

# Create your views here.

def evento_list(request):
    evento = list(filter(Evento.is_active, Evento.objects.order_by('fecha_exec')))
    contexto = {'evento': evento}
    return render(request, 'evento/evento_list.html', contexto)

class AsistenciaEventoCreate(CreateView):
    model = AsistenciaEvento
    template_name = 'evento/asistencia.html'
    form_class = AsistenciaForm
    success_url = reverse_lazy('eventos:evento_listar')

    def get_context_data(self, **kwargs):
        context = super(AsistenciaEventoCreate, self).get_context_data(**kwargs)
        if 'asistencia' not in context:
            context['asistencia'] = self.form_class(self.request.GET)
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(self.get_success_url())
        else:
            return self.render_to_response(self.get_context_data(form=form))
