from django.apps import AppConfig


class NoticiaConfig(AppConfig):
    name = 'noticia'
