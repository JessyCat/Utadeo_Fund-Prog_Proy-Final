import datetime
from django.db import models

# Create your models here.

class Noticia(models.Model):
    titulo = models.CharField(max_length=50, blank=False, unique=True)
    fecha_creacion = models.DateField(auto_now_add=True)
    desc = models.TextField()
    imagen1 = models.ImageField(upload_to='campana/%Y/%m/%d', blank=False)

    def __str__(self):
        return self.titulo

    def is_active(self):
        now = datetime.date.today()
        return self.fecha_exec > now