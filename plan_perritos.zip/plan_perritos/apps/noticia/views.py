from django.shortcuts import render
from .models import Noticia
# Create your views here.
def noticia_list(request):
    noticia = Noticia.objects.order_by('fecha_creacion')
    contexto = {'noticia': noticia}
    return render(request, 'noticia/noticia_list.html', contexto)