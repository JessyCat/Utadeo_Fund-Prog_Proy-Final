from django.urls import re_path
from .views import noticia_list

urlpatterns = [
    re_path(r'^', noticia_list, name='noticia_listar'),
]