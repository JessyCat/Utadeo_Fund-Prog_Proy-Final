from django.contrib import admin
from .models import Noticia
# Register your models here.
admin.site.register(Noticia)